package com.example.dickycrown.dog_support;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.DownloadListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Calendar;
import java.util.concurrent.CountDownLatch;

import android.webkit.WebChromeClient;
import android.widget.Toast;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.DataPointInterface;
import com.jjoe64.graphview.series.LineGraphSeries;
import com.jjoe64.graphview.series.OnDataPointTapListener;
import com.jjoe64.graphview.series.Series;

import static com.jjoe64.graphview.GridLabelRenderer.GridStyle.NONE;


public class MainActivity extends AppCompatActivity {
    String host = ""; //라즈베리파이 아이피
    String port = "8888";
    Socket socket = null;
    Handler handler = new Handler();

    private final Handler mHandler = new Handler();
    private Runnable mTimer1;
    private LineGraphSeries<DataPoint> mSeries1;
    private double graph2LastXValue = 5d;
    public int y=0;

    private WebView mWebView;
    TextView textView;

    boolean flag = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = getIntent();
        final String HOST = intent.getStringExtra("IP");
        host = HOST;

        textView = findViewById(R.id.textView3);
        mWebView = (WebView) findViewById(R.id.webview);//xml 자바코드 연결
        mWebView.getSettings().setLoadWithOverviewMode(true);
        mWebView.getSettings().setUseWideViewPort(true);
        mWebView.getSettings().setJavaScriptEnabled(true);//자바스크립트 허용
        mWebView.setWebChromeClient(new WebChromeClient());//웹뷰에 크롬 사용 허용
        mWebView.setWebViewClient(new WebViewClientClass());//새창열기 없이 웹뷰 내에서 다시 열기
        mWebView.loadData("<html><head><style type='text/css'>body{margin:auto auto;text-align:center;} " +
                "img{width:100%25;} div{overflow: hidden;} " +
                "</style></head><body><div><img src='http://" +
                host.toString() +
                ":8080/stream/video.mjpeg'/></div></body></html>",
                "text/html", "UTF-8"); //웹뷰 핸드폰 화면 사이즈에 맞도록 css를 수정
        //mWebView.loadUrl("http://" + host + ":8080");

        GraphView graph = (GraphView) findViewById(R.id.graph);
        mSeries1 = new LineGraphSeries<>();
        mSeries1.setThickness(10);
        mSeries1.setDataPointsRadius(10);
        mSeries1.setOnDataPointTapListener(new OnDataPointTapListener() {
            @Override
            public void onTap(Series series, DataPointInterface dataPoint) {
                Toast.makeText(getApplicationContext(), "Point clicked: "+dataPoint.getY(), Toast.LENGTH_SHORT).show();
            }
        });
        graph.addSeries(mSeries1);;
        graph.getViewport().setXAxisBoundsManual(true);
        graph.getViewport().setMinX(0);
        graph.getViewport().setMaxX(200); //그래프 범위지정
        graph.getGridLabelRenderer().setHorizontalLabelsVisible(false); //가로축 라벨가리기
        graph.getLegendRenderer().setVisible(false); //필요없는 그리드 없애기
        graph.getGridLabelRenderer().setGridStyle(GridLabelRenderer.GridStyle.HORIZONTAL);
        graph.getGridLabelRenderer().setVerticalAxisTitle("Bpm"); //그래프 축 이름 설정

        graph.getViewport().setScalable(true); // enables horizontal zooming and scrolling
        graph.getViewport().setScalableY(true);


        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() { //쿼드코어CPU처럼 메인쓰레드가아닌 다른쓰레드를 이용해서 소켓 데이터요청
                while(flag) {
                    try {
                        MyClientTask myClientTask = new MyClientTask(host, Integer.parseInt(port), "request");//request라는 소켓데이터를  라즈베리파이로 전달
                        myClientTask.execute(); //객체의 함수를 실행
                        handler.post(new Runnable() {
                            @Override
                            public void run() {

                            }
                        });
                        Thread.sleep(200);
                    } catch (InterruptedException e) { //오류나면 멈춤
                        break;

                    }
                }
            }
        });
        thread.start();

        mTimer1 = new Runnable() {
            @Override
            public void run() { //그래프 일정시간마다 출력하기
                //bpm_text.setText("BPM : "+BPM);
                graph2LastXValue += 1d;
                mSeries1.appendData(new DataPoint(graph2LastXValue,y), true, 300);
                mHandler.postDelayed(this, 100);
            }
        };
        mHandler.postDelayed(mTimer1, 200);

    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {//뒤로가기 버튼 이벤트
        if ((keyCode == KeyEvent.KEYCODE_BACK) && mWebView.canGoBack()) {//웹뷰에서 뒤로가기 버튼을 누르면 새로고침
            mWebView.reload();
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }
    private class WebViewClientClass extends WebViewClient {//페이지 이동
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            Log.d("check URL",url);
            view.loadUrl(url);
            return true;
        }
    }



    public class MyClientTask extends AsyncTask<Void, Void, Void> {
        String dstAddress; //ipadress
        int dstPort; //포트명
        String response = ""; //받는메세지
        String myMessage = ""; //송신메세지

        //constructor
        MyClientTask(String addr, int port, String message){
            dstAddress = addr;//ipadress
            dstPort = port; //포트명
            myMessage = message; //메세지
        }

        @Override
        protected Void doInBackground(Void... arg0) {

            Socket socket = null;
            myMessage = myMessage.toString();
            try {
                socket = new Socket(dstAddress, dstPort);
                //송신
                OutputStream out = socket.getOutputStream(); //송신측 설정
                out.write(myMessage.getBytes()); //송신메세지 사이즈와 함께전달

                //수신
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(1024); //수신측 1024사이즈
                byte[] buffer = new byte[1024]; //받을데이터 사이즈 선택하고
                int bytesRead;
                InputStream inputStream = socket.getInputStream(); //소켓에서 받은데이터를 inputStream에넣음

                while ((bytesRead = inputStream.read(buffer)) != -1){
                    byteArrayOutputStream.write(buffer, 0, bytesRead);
                    response += byteArrayOutputStream.toString("UTF-8"); //UTF-8으로 컨버트
                }
                response =response; //받은데이터

            } catch (UnknownHostException e) { //소켓통신오류
                e.printStackTrace();

                flag=false;
                response = "UnknownHostException: " + e.toString();
            } catch (IOException e) {
                e.printStackTrace();

                flag=false;
                response = "IOException: " + e.toString();
            }finally{
                if(socket != null){
                    try {
                        socket.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();

                        flag=false;
                    }
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) { //소켓 수신받으면 발생
            textView.setText(response); //테스트로 받은데이터 표시
            try{
                y= Integer.parseInt(response);
            }catch ( Exception e){

            }


            super.onPostExecute(result);
        }


    }
}


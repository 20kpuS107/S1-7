package com.example.dickycrown.dog_support;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main2Activity extends AppCompatActivity implements View.OnClickListener {
    Button connect;
    EditText IPtext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        connect= findViewById(R.id.connect_btn); //
        IPtext = findViewById(R.id.ip_edittext);

        findViewById(R.id.connect_btn).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) { //연결 버튼 누르면 ip를 인텐트에 담아 메인액티비티.java에 전달되는 동시에 실행된다.
        Intent intent = new Intent(this,MainActivity.class);
        intent.putExtra("IP",IPtext.getText().toString());
        startActivity(intent);
    }
}
